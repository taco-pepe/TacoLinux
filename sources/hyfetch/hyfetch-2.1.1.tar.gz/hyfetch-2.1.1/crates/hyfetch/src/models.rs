use std::collections::HashMap;

use anyhow::{Context as _, Result};
use serde::{Deserialize, Serialize};
use strum::{AsRefStr, Display, EnumString};

use crate::color_profile::ColorProfile;
use crate::color_util::Lightness;
use crate::color_util::LightnessPerTheme;
use crate::neofetch_util::ColorAlignment;
use crate::types::{AnsiMode, Backend, TerminalTheme};

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct Config {
    pub preset: PresetValue,
    pub mode: AnsiMode,
    pub auto_detect_light_dark: Option<bool>,
    pub light_dark: Option<TerminalTheme>,
    pub lightness: Option<Lightness>,
    pub lightness_per_theme: Option<LightnessPerTheme>,
    pub color_align: ColorAlignment,
    pub backend: Backend,
    #[serde(default)]
    #[serde(with = "self::args_serde")]
    pub args: Option<Vec<String>>,
    pub distro: Option<String>,
    pub pride_month_disable: bool,
    pub custom_ascii_path: Option<String>,
    pub custom_presets: Option<HashMap<String, Vec<String>>>,
    #[cfg(feature = "macchina")]
    pub palette_glyph: Option<String>,
    #[cfg(feature = "macchina")]
    pub palette_type: Option<String>
}

impl Config {
    pub fn default_lightness(theme: TerminalTheme) -> Lightness {
        match theme {
            TerminalTheme::Dark => {
                Lightness::new(0.65).expect("default lightness should not be invalid")
            },
            TerminalTheme::Light => {
                Lightness::new(0.4).expect("default lightness should not be invalid")
            },
        }
    }

    pub fn custom_preset_profiles(&self) -> Result<HashMap<String, ColorProfile>> {
        let mut profiles = HashMap::new();
        if let Some(custom_presets) = &self.custom_presets {
            for (preset_name, colors) in custom_presets {
                if preset_name == "random" {
                    return Err(anyhow::anyhow!("custom preset key `random` is reserved"));
                }
                let color_profile = build_hex_color_profile(colors).with_context(|| {
                    format!("failed to validate custom preset key `{preset_name}`")
                })?;
                profiles.insert(preset_name.clone(), color_profile);
            }
        }
        Ok(profiles)
    }
}

pub fn build_hex_color_profile(hex_colors: &[String]) -> Result<ColorProfile> {
    if hex_colors.is_empty() {
        return Err(anyhow::anyhow!("hex color list cannot be empty"));
    }

    for color in hex_colors {
        if !color.starts_with('#')
            || (color.len() != 4 && color.len() != 7)
            || !color[1..].chars().all(|c| c.is_ascii_hexdigit())
        {
            return Err(anyhow::anyhow!("invalid hex color: {color}"));
        }
    }

    ColorProfile::from_hex_colors(hex_colors.to_vec())
        .context("failed to create color profile from hex")
}

mod args_serde {
    use std::fmt;

    use serde::de::{self, value, Deserialize, Deserializer, SeqAccess, Visitor};
    use serde::ser::Serializer;

    type Value = Option<Vec<String>>;

    pub(super) fn serialize<S>(value: &Value, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        match value {
            Some(value) => serializer.serialize_some(&shell_words::join(value)),
            None => serializer.serialize_none(),
        }
    }

    pub(super) fn deserialize<'de, D>(deserializer: D) -> Result<Value, D::Error>
    where
        D: Deserializer<'de>,
    {
        struct StringOrVec;

        struct OptionVisitor;

        impl<'de> Visitor<'de> for StringOrVec {
            type Value = Vec<String>;

            fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
                formatter.write_str("string or list of strings")
            }

            fn visit_str<E>(self, s: &str) -> Result<Self::Value, E>
            where
                E: de::Error,
            {
                shell_words::split(s).map_err(de::Error::custom)
            }

            fn visit_seq<S>(self, seq: S) -> Result<Self::Value, S::Error>
            where
                S: SeqAccess<'de>,
            {
                Deserialize::deserialize(value::SeqAccessDeserializer::new(seq))
            }
        }

        impl<'de> Visitor<'de> for OptionVisitor {
            type Value = Value;

            fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
                formatter.write_str("option")
            }

            #[inline]
            fn visit_unit<E>(self) -> Result<Self::Value, E>
            where
                E: de::Error,
            {
                Ok(None)
            }

            #[inline]
            fn visit_none<E>(self) -> Result<Self::Value, E>
            where
                E: de::Error,
            {
                Ok(None)
            }

            #[inline]
            fn visit_some<D>(self, deserializer: D) -> Result<Self::Value, D::Error>
            where
                D: Deserializer<'de>,
            {
                deserializer.deserialize_any(StringOrVec).map(Some)
            }
        }

        deserializer.deserialize_option(OptionVisitor)
    }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(untagged)]
pub enum PresetValue {
    Single(String),
    Multiple(Vec<String>),
}

impl From<String> for PresetValue {
    fn from(s: String) -> Self {
        PresetValue::Single(s)
    }
}

impl PresetValue {
    pub fn get_random_if_multiple(&self) -> String {
        match self {
            PresetValue::Single(s) => s.clone(),
            PresetValue::Multiple(v) => {
                if v.is_empty() {
                    "random".to_owned()
                } else {
                    let mut rng = fastrand::Rng::new();
                    let selected_index = rng.usize(0..v.len());
                    v[selected_index].clone()
                }
            }
        }
    }
}

// handling macchina palettes
#[derive(Clone, Debug, Display, EnumString, Deserialize, Serialize, AsRefStr)]
pub enum Palette {
    #[strum(to_string = "Full", ascii_case_insensitive)]
    Full(String),
    #[strum(to_string = "Light", ascii_case_insensitive)]
    Light(String),
    #[strum(to_string = "Dark", ascii_case_insensitive)]
    Dark(String)
}

impl Palette {
    pub fn get_glyph(&self) -> &String {
        match self {
            Palette::Full(s) => s,
            Palette::Light(s) => s,
            Palette::Dark(s) => s
        }
    }
    pub fn get_glyph_mut(&mut self) -> &mut String {
        match self {
            Palette::Full(s) => s,
            Palette::Light(s) => s,
            Palette::Dark(s) => s
        }
    }
    pub fn shift_type(&mut self, go_right: bool) {
        *self = if go_right {
            match self {
                Palette::Full(s) => Palette::Light(s.to_owned()),
                Palette::Light(s) => Palette::Dark(s.to_owned()),
                Palette::Dark(s) => Palette::Full(s.to_owned())
            }
        } else {
            match self {
                Palette::Full(s) => Palette::Dark(s.to_owned()),
                Palette::Light(s) => Palette::Full(s.to_owned()),
                Palette::Dark(s) => Palette::Light(s.to_owned())
            }
        }
    }
}

#[test]
fn test() {
    println!("{:?}", Palette::Full("".to_owned()))
}

