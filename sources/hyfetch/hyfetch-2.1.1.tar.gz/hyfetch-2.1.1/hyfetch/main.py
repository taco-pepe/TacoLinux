#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime
import importlib.util
import json
import os
import random
import re
import sys
import traceback
from itertools import permutations, islice
from math import ceil

from . import termenv, neofetch_util, pride_month
from .color_scale import Scale
from .color_util import clear_screen
from .constants import *
from .distros import distro_detector
from .font_logo import get_font_logo
from .models import build_hex_color_profile, Config
from .neofetch_util import *
from .presets import PRESETS, ColorProfile


def parse_hex_colors(text: str) -> list[str]:
    """
    Parse hex colors from text, allowing space or comma separation,
    with or without '#' prefix, supporting 3 or 6 hex digits.
    """
    tokens = re.split(r'[,;\s]+', text.strip())
    colors = []
    for tok in tokens:
        if not tok:
            continue
        c = tok.lstrip('#')
        if len(c) in (3, 6) and all(ch in '0123456789abcdefABCDEF' for ch in c):
            colors.append(f'#{c}')
    return colors



def check_config(path) -> Config:
    """
    Check if the configuration exists. Return the config object if it exists. If not, call the
    config creator

    :return: Config object
    """
    if path.is_file():
        try:
            return Config.from_dict(json.loads(path.read_text('utf-8')))
        except KeyError:
            return create_config(path)

    return create_config(path)


def create_config(path: Path | None = None) -> Config:
    """
    Create config interactively

    :return: Config object (automatically stored)
    """
    # Detect terminal environment (doesn't work on Windows)
    det_bg = termenv.get_background_color()
    det_ansi = termenv.detect_ansi_mode()

    asc = get_distro_ascii()
    asc_width, asc_lines = ascii_size(asc)
    logo = color("&l&bhyfetch&~&L" if det_bg is None or det_bg.is_light() else "&l&bhy&ffetch&~&L")
    title = f'Welcome to {logo} Let\'s set up some colors first.'
    clear_screen(title)

    option_counter = 1

    def update_title(k: str, v: str):
        nonlocal title, option_counter
        if not k.endswith(":"):
            k += ':'
        title += f"\n&e{option_counter}. {k.ljust(30)} &~{v}"
        option_counter += 1

    def print_title_prompt(prompt: str):
        printc(f'&a{option_counter}. {prompt}')

    ##############################
    # 0. Check term size
    try:
        term_len, term_lines = os.get_terminal_size().columns, os.get_terminal_size().lines
        term_len_min = 2 * asc_width + 4
        term_lines_min = 30
        if term_len < term_len_min or term_lines < term_lines_min:
            printc(f'&cWarning: Your terminal is too small ({term_len} * {term_lines}). \n'
                   f'Please resize it to at least ({term_len_min} * {term_lines_min}) for better experience.')
            input('Press enter to ignore...')
    except:
        # print('Warning: We cannot detect your terminal size.')
        pass

    ##############################
    # 1. Select color system
    def select_color_system():
        if det_ansi == 'rgb':
            return 'rgb', 'Detected color mode'

        clear_screen(title)
        term_len, term_lines = term_size()

        scale2 = Scale(['#12c2e9', '#c471ed', '#f7797d'])
        _8bit = [scale2(i / term_len).to_ansi_8bit(False) for i in range(term_len)]
        _rgb = [scale2(i / term_len).to_ansi_rgb(False) for i in range(term_len)]

        printc('&f' + ''.join(c + t for c, t in zip(_8bit, '8bit Color Testing'.center(term_len))))
        printc('&f' + ''.join(c + t for c, t in zip(_rgb, 'RGB Color Testing'.center(term_len))))

        print()
        print_title_prompt('Which &bcolor system &ado you want to use?')
        printc(f'(If you can\'t see colors under "RGB Color Testing", please choose 8bit)')
        print()

        return literal_input('Your choice?', ['8bit', 'rgb'], 'rgb'), 'Selected color mode'

    # Override global color mode
    color_system, ttl = select_color_system()
    GLOBAL_CFG.color_mode = color_system
    update_title(ttl, color_system)

    ##############################
    # 2. Select light/dark mode
    def select_light_dark():
        if det_bg is not None:
            return det_bg.is_light(), 'Detected background color'

        clear_screen(title)
        inp = literal_input(f'2. Is your terminal in &blight mode&~ or &4dark mode&~?',
                            ['light', 'dark'], 'dark')
        return inp == 'light', 'Selected background color'

    is_light, ttl = select_light_dark()
    light_dark = 'light' if is_light else 'dark'
    GLOBAL_CFG.is_light = is_light
    update_title(ttl, light_dark)

    ##############################
    # 3. Choose preset
    # Create flags = [[lines]]
    flag_entries = []
    spacing = max(
        max(len(k) for k in PRESETS.keys()),
        max(len(preset.colors) for preset in PRESETS.values()),
        20,
    )
    for name, preset in PRESETS.items():
        flag = preset.color_text(' ' * spacing, foreground=False)
        flag_entries.append((name, [name.center(spacing), flag, flag, flag], name.lower()))

    # Add custom flag option
    custom_profile = build_hex_color_profile(['#e06c75', '#e5c07b', '#98c379', '#56b6c2', '#61afef', '#c678dd'])
    custom_flag = custom_profile.set_light_dl_def(light_dark).color_text(' ' * spacing, foreground=False)
    flag_entries.append(('custom', ['custom'.center(spacing), custom_flag, custom_flag, custom_flag], 'custom'))

    # Calculate flags per row
    flags_per_row = max(1, term_size()[0] // (spacing + 2))
    row_per_page = max(1, (term_size()[1] - 13) // 5)
    flags_per_page = flags_per_row * row_per_page

    def filter_flag_indices(query: str) -> list[int]:
        if not query:
            return list(range(len(flag_entries)))

        matched = []
        for idx, (_, _, lower_name) in enumerate(flag_entries):
            pos = lower_name.find(query)
            if pos == -1:
                continue
            matched.append((0 if lower_name.startswith(query) else 1, pos, idx))
        matched.sort()
        return [idx for _, _, idx in matched]

    def select_preset_prompt_toolkit() -> str:
        from prompt_toolkit import PromptSession
        from prompt_toolkit.application.current import get_app
        from prompt_toolkit.formatted_text import ANSI
        from prompt_toolkit.key_binding import KeyBindings

        page_num = 0
        prompt_header = PRESETS['rainbow'].set_light_dl_def(light_dark).color_text('preset')
        kb = KeyBindings()
        last_filter = ''

        def current_num_pages() -> int:
            text = get_app().current_buffer.text.lower().strip()
            indices = filter_flag_indices(text)
            return max(1, ceil(len(indices) / flags_per_page))

        @kb.add('up')
        def _prev_page(event):
            nonlocal page_num
            page_num = (page_num + current_num_pages() - 1) % current_num_pages()
            event.app.invalidate()

        @kb.add('down')
        def _next_page(event):
            nonlocal page_num
            page_num = (page_num + 1) % current_num_pages()
            event.app.invalidate()

        @kb.add('escape')
        def _clear_filter(event):
            nonlocal page_num
            event.current_buffer.text = ''
            event.current_buffer.cursor_position = 0
            page_num = 0
            event.app.invalidate()

        def build_preset_lines(text_filter: str):
            nonlocal page_num
            filtered_indices = filter_flag_indices(text_filter.lower().strip())
            num_pages = max(1, ceil(len(filtered_indices) / flags_per_page))
            page_num = min(page_num, num_pages - 1)

            lines = [
                color(f"&a{option_counter}. Let's choose a flag!&r"),
                "Available flag presets:",
                f"Page: {page_num + 1} of {num_pages}",
                "",
            ]

            start = page_num * flags_per_page
            end = min(start + flags_per_page, len(filtered_indices))
            visible_row_count = 0
            if start >= end:
                lines.append("No presets matched this filter.")
                visible_row_count = 0.2
            else:
                current = filtered_indices[start:end]
                for i in range(0, len(current), flags_per_row):
                    row = [flag_entries[idx][1] for idx in current[i:i + flags_per_row]]
                    lines.extend('  '.join(line) for line in zip(*row))
                    lines.append("")
                    visible_row_count += 1

            # Keep prompt at a fixed vertical position by padding to a full page height.
            missing_rows = max(0, row_per_page - visible_row_count)
            lines.extend([""] * round(missing_rows * 5))

            lines.append(
                "Use the up/down arrow keys to go to the previous/next page. Type to filter and press Enter to select."
            )
            lines.append(f"Which {prompt_header} do you want to use? (default: rainbow)")
            return lines

        def prompt_message():
            nonlocal last_filter
            app = get_app()
            text_filter = app.current_buffer.text
            last_filter = text_filter

            lines = build_preset_lines(text_filter)
            return ANSI('\n'.join(lines) + '\n> ')

        clear_screen(title)
        session = PromptSession(key_bindings=kb)
        try:
            selection = session.prompt(prompt_message).strip().lower()
        except KeyboardInterrupt:
            clear_screen(title)
            for line in build_preset_lines(last_filter):
                print(line)
            print(f"> {last_filter}")
            raise

        if selection == 'custom':
            return 'custom'
        if '#' in selection:
            parsed = parse_hex_colors(selection)
            if parsed:
                return ','.join(parsed)

        filtered_indices = filter_flag_indices(selection)
        if selection in PRESETS:
            return selection
        if filtered_indices:
            return flag_entries[filtered_indices[0]][0]
        return 'rainbow'

    def prompt_custom_flag() -> str:
        from prompt_toolkit import PromptSession
        from prompt_toolkit.application.current import get_app
        from prompt_toolkit.formatted_text import ANSI
        from prompt_toolkit.key_binding import KeyBindings

        last_input = ''
        hint: str | None = None
        kb = KeyBindings()

        @kb.add('escape')
        def _cancel(event):
            event.app.exit(result='__cancel__')

        def build_custom_lines(raw_input: str) -> list[str]:
            colors = parse_hex_colors(raw_input)
            lines = [
                color(f"&a{option_counter}. Let's set up your custom flag!&r"),
                "Enter colors separated by spaces or commas (e.g. ff0000 00ff00 0000ff or #f00 #0f0):",
                "",
                "Flag preview:",
            ]
            if colors:
                try:
                    profile = build_hex_color_profile(colors)
                    preview = profile.set_light_dl_def(light_dark).color_text(' ' * spacing, foreground=False)
                    lines.append(preview)
                    lines.append(preview)
                    lines.append(preview)
                    swatches = '  '.join(
                        f"{c_obj.to_ansi(foreground=True)}██&r {c}"
                        for c_obj, c in zip(profile.colors, colors)
                    )
                    lines.append(color(f"Colors ({len(colors)}): {swatches}"))
                except Exception:
                    lines.extend(["(invalid colors)", "", "", ""])
            else:
                lines.append("(type hex colors to preview flag)")
                lines.append("")
                lines.append("")
                lines.append("")
            lines.append("")
            lines.append("Press Enter to select this flag, or Esc / Ctrl+C to cancel.")
            if hint:
                lines.append(color(f"&c{hint}&r"))
            return lines

        def prompt_message():
            nonlocal last_input
            app = get_app()
            raw_input = app.current_buffer.text
            last_input = raw_input
            lines = build_custom_lines(raw_input)
            return ANSI('\n'.join(lines) + '\n> ')

        session = PromptSession(key_bindings=kb)
        default_val = ''
        while True:
            clear_screen(title)
            try:
                line = session.prompt(prompt_message, default=default_val).strip()
            except KeyboardInterrupt:
                clear_screen(title)
                for l in build_custom_lines(last_input):
                    print(l)
                print(f"> {last_input}")
                raise

            if line == '__cancel__':
                return 'rainbow'

            tokens = [t for t in re.split(r'[,;\s]+', line.strip()) if t]
            if not tokens:
                hint = "Please enter at least one valid hex color (e.g. ff0000)."
                default_val = ''
                continue

            colors = []
            invalid_tokens = []
            for tok in tokens:
                c = tok.lstrip('#')
                if len(c) in (3, 6) and all(ch in '0123456789abcdefABCDEF' for ch in c):
                    colors.append(f'#{c}')
                else:
                    invalid_tokens.append(tok)

            if invalid_tokens:
                hint = f"Invalid hex color(s): {', '.join(invalid_tokens)}. Use 3 or 6 hex digits (e.g. ff0000 or #f00)."
                default_val = line
                continue

            return ','.join(colors)

    preset = select_preset_prompt_toolkit()
    if preset == 'custom':
        preset = prompt_custom_flag()

    if '#' in preset:
        colors = [s.strip() for s in preset.split(',')]
        _prs = build_hex_color_profile(colors)
    else:
        _prs = PRESETS[preset]
    update_title('Selected flag', _prs.set_light_dl_def(light_dark).color_text(preset))

    #############################
    # 4. Dim/lighten colors
    def select_lightness():
        clear_screen(title)
        print_title_prompt("Let's adjust the color brightness!")
        printc(f'The colors might be a little bit too {"bright" if is_light else "dark"} for {light_dark} mode.')
        print()

        # Print cats
        num_cols = (term_size()[0] // (TEST_ASCII_WIDTH + 2)) or 1
        mn, mx = 0.15, 0.85
        ratios = [col / num_cols for col in range(num_cols)]
        ratios = [(r * (mx - mn) / 2 + mn) if is_light else ((r * (mx - mn) + (mx + mn)) / 2) for r in ratios]
        lines = [ColorAlignment('horizontal').recolor_ascii(TEST_ASCII.replace(
            '{txt}', f'{r * 100:.0f}%'.center(5)), _prs.set_light_dl(r, light_dark)).split('\n') for r in ratios]
        [printc('  '.join(line)) for line in zip(*lines)]

        def_lightness = GLOBAL_CFG.default_lightness(light_dark)

        while True:
            print()
            printc(f'Which brightness level looks the best? (Default: {def_lightness * 100:.0f}% for {light_dark} mode)')
            lightness = input('> ').strip().lower() or None

            # Parse lightness
            if not lightness or lightness in ['unset', 'none']:
                return def_lightness

            try:
                if lightness.endswith('%') or int(lightness) > 1:
                    lightness = int(lightness[:-1]) / 100 if lightness.endswith('%') else int(lightness) / 100
                else:
                    lightness = float(lightness)
                assert 0 <= lightness <= 1
                return lightness

            except Exception:
                printc('&cUnable to parse lightness value, please enter a lightness value such as 45%, .45, or 45')

    lightness = select_lightness()
    _prs = _prs.set_light_dl(lightness, light_dark)
    update_title('Selected Brightness', f"{lightness:.2f}")

    ##############################
    # 5. Choose Default, Old, or Small Logo
    tmp_dst = GLOBAL_CFG.override_distro or get_distro_name()
    detected_dst = GLOBAL_CFG.override_distro
    if not detected_dst:
        det = distro_detector.detect(tmp_dst)
        detected_dst = det.name if det else tmp_dst
    detected_dst = (detected_dst or '').lower()

    raw_dst = detected_dst
    base_distro = raw_dst
    for suffix in ('_small', '_old'):
        if base_distro.endswith(suffix):
            base_distro = base_distro[:-len(suffix)]
            break

    running_dst_old = f"{base_distro}_old" if distro_detector.detect(f"{base_distro}_old") else ""
    running_dst_sml = f"{base_distro}_small" if distro_detector.detect(f"{base_distro}_small") else ""

    default_asc = get_distro_ascii(base_distro) if (raw_dst.endswith('_old') or raw_dst.endswith('_small')) else asc
    old_asc = get_distro_ascii(running_dst_old) if running_dst_old else None
    small_asc = get_distro_ascii(running_dst_sml) if running_dst_sml else None

    logo_chosen: str | None = GLOBAL_CFG.override_distro

    ds_arrangements = [
        ('Default', default_asc)
    ]
    if old_asc and old_asc.strip().splitlines() != default_asc.strip().splitlines():
        ds_arrangements.append(('Old', old_asc))
    if small_asc and small_asc.strip().splitlines() != default_asc.strip().splitlines():
        ds_arrangements.append(('Small', small_asc))

    if len(ds_arrangements) > 1:
        has_old = 'Old' in [k for k, _ in ds_arrangements]
        has_small = 'Small' in [k for k, _ in ds_arrangements]

        max_h = max(ascii_size(a)[1] for _, a in ds_arrangements)
        max_w = max(ascii_size(a)[0] for _, a in ds_arrangements)

        while True:
            clear_screen(title)

            term_w = term_size()[0]
            ascii_per_row = max(1, term_w // (max_w + 6))

            asciis = []
            for k, a in ds_arrangements:
                w, h = ascii_size(a)
                v_dst = running_dst_old if k == 'Old' else (running_dst_sml if k == 'Small' else base_distro)
                v_ca = ColorAlignment('horizontal', fore_back=get_fore_back(v_dst))
                lines = v_ca.recolor_ascii(a, _prs).split('\n')
                pad_top = (max_h - len(lines)) // 2
                pad_bottom = max_h - len(lines) - pad_top
                padded = [' ' * w] * pad_top + lines + [' ' * w] * pad_bottom
                padded.append(k.center(w))
                asciis.append(padded)

            while asciis:
                current = asciis[:ascii_per_row]
                asciis = asciis[ascii_per_row:]
                for line in zip(*current):
                    printc('        '.join(line))
                print()

            if has_old and has_small:
                prompt_text = "Do you want the default logo, the old logo, or the small logo?"
                opts = ['default', 'old', 'small']
            elif has_old:
                prompt_text = "Do you want the default logo, or the old logo?"
                opts = ['default', 'old']
            else:
                prompt_text = "Do you want the default logo, or the small logo?"
                opts = ['default', 'small']

            print_title_prompt(prompt_text)
            choice = literal_input('Your choice?', opts, 'default')

            if choice == 'old':
                logo_chosen = running_dst_old
                asc = old_asc
            elif choice == 'small':
                logo_chosen = running_dst_sml
                asc = small_asc
            else:
                logo_chosen = base_distro if GLOBAL_CFG.override_distro else None
                asc = default_asc

            asc_width, asc_lines = ascii_size(asc)
            update_title('Selected logo type', choice)
            break

    #############################
    # 6. Color arrangement
    color_alignment = None
    fore_back = get_fore_back(logo_chosen or base_distro)

    # Calculate amount of row/column that can be displayed on screen
    ascii_per_row = max(1, term_size()[0] // (asc_width + 2))
    ascii_rows = max(1, (term_size()[1] - 8) // asc_lines)

    slots = sorted(set(map(int, re.findall(r'(?<=\${c)[0-9]+(?=})', asc))))

    # Displays horizontal and vertical arrangements in the first iteration, but hide them in
    # later iterations
    hv_arrangements = [
        ('Horizontal', ColorAlignment('horizontal', fore_back=fore_back)),
        ('Vertical', ColorAlignment('vertical')),
    ]
    arrangements = hv_arrangements.copy()

    # Loop for random rolling
    is_first = True
    while True:
        clear_screen(title)

        # Random color schemes
        pis = list(range(len(_prs.unique_colors().colors)))
        slots = sorted(set(map(int, re.findall(r'(?<=\${c)[0-9]+(?=})', asc))))
        while len(pis) < len(slots):
            pis += pis
        perm = {p[:len(slots)] for p in islice(permutations(pis), 1000)}
        random_count = max(0, ascii_per_row * ascii_rows - len(arrangements))

        is_sequential = is_first and len(_prs.unique_colors().colors) == len(slots)
        if random_count == 0:
            choices = []
        elif is_sequential:
            ordered_p = tuple(pis[:len(slots)])
            other_perms = [p for p in perm if p != ordered_p]
            sample_count = random_count - 1
            if sample_count >= len(other_perms):
                choices = [ordered_p] + other_perms
            else:
                choices = [ordered_p] + random.sample(sorted(other_perms), min(sample_count, len(other_perms)))
        else:
            if random_count >= len(perm):
                choices = list(perm)
            else:
                choices = random.sample(sorted(perm), random_count)

        choices = [{slots[i]: n for i, n in enumerate(c)} for c in choices]
        arrangements += [(f'random{i}', ColorAlignment('custom', r)) for i, r in enumerate(choices)]
        asciis = [[*ca.recolor_ascii(asc, _prs).split('\n'), k.center(asc_width)] for k, ca in arrangements]

        while asciis:
            current = asciis[:ascii_per_row]
            asciis = asciis[ascii_per_row:]

            # Print by row
            [printc('  '.join(line)) for line in zip(*current)]
            print()

        print_title_prompt("Let's choose a color arrangement!")
        printc(f'You can choose standard horizontal or vertical alignment, or use one of the random color schemes. You can type "roll" to randomize again. Additionally, \'truerandom\' will generate a fresh random color scheme every time hyfetch runs.')
        print()
        choice = literal_input(f'Your choice?', ['horizontal', 'vertical', 'roll', 'truerandom'] + [f'random{i}' for i in range(random_count)], 'horizontal')

        if choice == 'roll':
            arrangements = []
            is_first = False
            continue

        # Save choice
        arrangement_index = {k.lower(): ca for k, ca in hv_arrangements + arrangements + [("TrueRandom", ColorAlignment('random'))]}
        if choice in arrangement_index:
            color_alignment = arrangement_index[choice]
        else:
            print('Invalid choice.')
            continue

        break

    update_title('Color alignment', color_alignment)

    ##############################
    # 6. Select *fetch backend
    def select_backend():
        clear_screen(title)
        print_title_prompt('Select a *fetch backend')

        # Check if fastfetch is installed
        ff_path = fastfetch_path()

        # Check if qwqfetch is installed (if the qwqfetch module can be imported)
        has_qwqfetch = importlib.util.find_spec('qwqfetch') is not None

        printc('- &bneofetch&r: Written in bash, &nbest compatibility&r on Unix systems')
        printc('- &bfastfetch&r: Written in C, &nbest performance&r ' +
               ('&c(Not installed)' if ff_path is None else f'&a(Installed at {ff_path})'))
        printc('- &bqwqfetch&r: Pure python, &nminimal dependencies&r ' +
               ('&c(Not installed)' if not has_qwqfetch else ''))
        print()

        # Use fastfetch as the default backend if it is installed
        def_backend = 'neofetch' if ff_path is None else 'fastfetch'

        return literal_input('Your choice?', ['neofetch', 'fastfetch', 'qwqfetch'], def_backend)

    backend = select_backend()
    update_title('Selected backend', backend)

    ##############################
    # 7. Custom ASCII file
    custom_ascii_path = None
    clear_screen(title)
    if literal_input('Do you want to specify a custom ASCII file?', ['y', 'n'], 'n') == 'y':
        while True:
            path_input = input('Path to custom ASCII file (must be .txt and UTF-8 encoded): ').strip()
            if not path_input:
                printc('&cNo path entered. Skipping custom ASCII file.')
                break

            custom_path = Path(path_input)
            if not custom_path.is_file():
                printc(f'&cError: File not found at {path_input}')
                if literal_input('Try again?', ['y', 'n'], 'y') == 'n':
                    break
                continue

            if not custom_path.suffix == '.txt':
                printc(f'&cError: File must have a .txt extension. Found {custom_path.suffix}')
                if literal_input('Try again?', ['y', 'n'], 'y') == 'n':
                    break
                continue

            try:
                custom_path.read_text('utf-8')
                custom_ascii_path = str(custom_path)
                update_title('Custom ASCII file', custom_ascii_path)
                break
            except UnicodeDecodeError:
                printc(f'&cError: File is not UTF-8 encoded.')
                if literal_input('Try again?', ['y', 'n'], 'y') == 'n':
                    break
                continue
            except Exception as e:
                printc(f'&cAn unexpected error occurred: {e}')
                if literal_input('Try again?', ['y', 'n'], 'y') == 'n':
                    break
                continue

    # Create config
    clear_screen(title)
    c = Config(preset, color_system, light_dark, lightness, color_alignment, backend, distro=logo_chosen, custom_ascii_path=custom_ascii_path)

    # Save config
    print()
    save = literal_input(f'Save config?', ['y', 'n'], 'y')
    if save == 'y':
        c.save(path)

    return c


def create_parser() -> argparse.ArgumentParser:
    # Create CLI
    hyfetch = color('&l&bhyfetch&~&L')
    parser = argparse.ArgumentParser(description=color(f'{hyfetch} - neofetch with flags <3'), prog="hyfetch")

    parser.add_argument('-c', '--config', action='store_true', help=color(f'Configure hyfetch'))
    parser.add_argument('-C', '--config-file', dest='config_file', default=CONFIG_PATH, help=f'Use another config file')
    parser.add_argument('-p', '--preset', help=f'Use preset or comma-separated hex color list (e.g., "#ff0000,#00ff00,#0000ff")')
    parser.add_argument('-m', '--mode', help=f'Color mode', choices=['8bit', 'rgb'])
    parser.add_argument('-b', '--backend', help=f'Choose a *fetch backend', choices=['qwqfetch', 'neofetch', 'fastfetch', 'fastfetch-old'])
    parser.add_argument('--args', help=f'Additional arguments pass-through to backend')
    parser.add_argument('--c-scale', dest='scale', help=f'Lighten colors by a multiplier', type=float)
    parser.add_argument('--c-set-l', dest='light', help=f'Set lightness value of the colors', type=float)
    parser.add_argument('--c-overlay', action='store_true', dest='overlay', help=f'Use experimental overlay color adjusting instead of HSL lightness')
    parser.add_argument('-V', '--version', dest='version', action='store_true', help=f'Check version')
    parser.add_argument('--june', action='store_true', help=f'Show pride month easter egg')
    parser.add_argument('--debug', action='store_true', help=f'Debug mode')
    parser.add_argument('-r', '--random-alignment', action='store_true', help=color(f'Use a fresh random color alignment every time, independent of config'))

    parser.add_argument('--distro', '--test-distro', dest='distro', help=f'Test for a specific distro')
    parser.add_argument('--ascii-file', help='Use a specific file for the ascii art')
    parser.add_argument('--print-font-logo', action='store_true', help='Print the Font Logo / Nerd Font icon of your distro and exit')

    # Hidden debug arguments
    # --test-print: Print the ascii distro and exit
    parser.add_argument('--test-print', action='store_true', help=argparse.SUPPRESS)
    # --ask-exit: Ask for input before exiting
    parser.add_argument('--ask-exit', action='store_true', help=argparse.SUPPRESS)

    return parser


def run():
    # Optional: Import readline
    try:
        import readline
    except ModuleNotFoundError:
        pass

    # On Windows: Try to fix color rendering if not in git bash
    if IS_WINDOWS:
        import colorama
        colorama.just_fix_windows_console()

    parser = create_parser()
    args = parser.parse_args()

    # Use a custom distro
    GLOBAL_CFG.override_distro = args.distro
    GLOBAL_CFG.use_overlay = args.overlay

    if args.version:
        print(f'Version is 1.99.∞\n(python hyfetch legacy mode)')
        return

    # Ensure git bash for windows
    ensure_git_bash()
    check_windows_cmd()

    if args.debug:
        GLOBAL_CFG.debug = True

    if args.test_print:
        print(get_distro_ascii())
        return

    if args.print_font_logo:
        print(get_font_logo())
        return

    # Check if user provided alternative config path
    if not args.config_file == CONFIG_PATH:
        args.config_file = Path(os.path.abspath(args.config_file))

        # If provided file does not exist use default config
        if not args.config_file.is_file():
            args.config_file = CONFIG_PATH

    # Load config or create config
    config = create_config(args.config_file) if args.config else check_config(args.config_file)

    # Check if it's June (pride month)
    now = datetime.datetime.now()
    june_path = CACHE_PATH / f'animation-displayed-{now.year}'
    show_for_june = False
    if now.month == 6 and now.year not in config.pride_month_shown and not june_path.is_file() and os.isatty(sys.stdout.fileno()):
        show_for_june = True

    if (args.june or show_for_june) and not config.pride_month_disable:
        pride_month.start_animation()
        print()
        print("Happy pride month!")
        print("(You can always view the animation again with `hyfetch --june`)")
        print()

        if not june_path.is_file() and not args.june: # If --june wasn't explicitly specified...
            june_path.parent.mkdir(parents=True, exist_ok=True)
            june_path.touch()

    # Use a custom distro
    GLOBAL_CFG.override_distro = (config.distro if args.config else (args.distro or config.distro))

    # Param overwrite config
    if args.preset:
        config.preset = args.preset
    if args.mode:
        config.mode = args.mode
    if args.backend:
        config.backend = args.backend
    if args.args:
        config.args = args.args
    # Override global color mode
    GLOBAL_CFG.color_mode = config.mode
    GLOBAL_CFG.is_light = config.light_dark == 'light'

    # Get preset
    def parse_preset_string(preset_string: str, config: Config) -> ColorProfile:
        if '#' in preset_string:
            colors = [s.strip() for s in preset_string.split(',')]
            return build_hex_color_profile(colors)

        preset_profiles: dict[str, ColorProfile] = {
            name: preset for name, preset in PRESETS.items()
        }
        preset_profiles.update(config.custom_preset_profiles())

        presets = list(preset_profiles.values())

        if preset_string == 'random':
            if not presets:
                raise ValueError('preset iterator should not be empty')
            return random.choice(presets)

        if preset_string in preset_profiles:
            return preset_profiles[preset_string]

        available = sorted([*preset_profiles.keys(), 'random'])
        raise ValueError(
            "PRESET should be comma-separated hex colors or one of "
            f"{{{','.join(available)}}}"
        )

    try:
        preset = parse_preset_string(config.preset, config)
    except ValueError as err:
        print(f'Error: {err}')
        exit(1)

    # Lighten (args > config)
    if args.scale:
        preset = preset.lighten(args.scale)
    elif args.light:
        preset = preset.set_light_raw(args.light)
    else:
        preset = preset.set_light_dl(config.lightness or GLOBAL_CFG.default_lightness())

    # Run
    try:
        if args.ascii_file:
            asc = Path(args.ascii_file).read_text("utf-8")
        elif config.custom_ascii_path:
            asc = Path(config.custom_ascii_path).read_text("utf-8")
        else:
            asc = get_distro_ascii()
        color_align: ColorAlignment = get_random_alignment(preset, asc) if (args.random_alignment or config.color_align.mode == "random") else config.color_align
        asc = color_align.recolor_ascii(asc, preset)
        neofetch_util.run(asc, config.backend, config.args or '')
    except Exception as e:
        print(f'Error: {e}')
        traceback.print_exc()

    if args.ask_exit:
        input('Press any key to exit...')
